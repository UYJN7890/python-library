import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk
from datetime import date
from pathlib import Path


DB_PATH = Path(__file__).with_name("library.db")


DEMO_BOOKS = [
    ("Преступление и наказание", "Ф. М. Достоевский", 1866, "Роман", 3, 3),
    ("Война и мир", "Л. Н. Толстой", 1869, "Роман", 4, 4),
    ("Мастер и Маргарита", "М. А. Булгаков", 1967, "Роман", 2, 2),
    ("Анна Каренина", "Л. Н. Толстой", 1878, "Роман", 3, 3),
    ("Маленький принц", "Антуан де Сент-Экзюпери", 1943, "Сказка", 5, 5),
    ("1984", "Джордж Оруэлл", 1949, "Антиутопия", 3, 3),
    ("Гарри Поттер и философский камень", "Дж. К. Роулинг", 1997, "Фэнтези", 4, 4),
    ("Три товарища", "Эрих Мария Ремарк", 1936, "Роман", 2, 2),
    ("Собачье сердце", "М. А. Булгаков", 1925, "Повесть", 3, 3),
    ("Солнечный ветер", "Александр Беляев", 1926, "Фантастика", 2, 2),
]


class LibraryDatabase:
    def __init__(self, path):
        self.connection = sqlite3.connect(path)
        self.connection.row_factory = sqlite3.Row
        self.create_tables()
        self.seed_data()

    def create_tables(self):
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                year INTEGER NOT NULL,
                genre TEXT NOT NULL,
                total INTEGER NOT NULL CHECK (total >= 0),
                available INTEGER NOT NULL CHECK (available >= 0)
            );

            CREATE TABLE IF NOT EXISTS loans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id INTEGER NOT NULL,
                reader_name TEXT NOT NULL,
                issue_date TEXT NOT NULL,
                returned INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY (book_id) REFERENCES books(id)
            );
            """
        )
        self.connection.commit()

    def seed_data(self):
        if self.connection.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            self.connection.executemany(
                "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                [
                    ("admin", "admin", "admin"),
                    ("librarian", "library", "librarian"),
                ],
            )
            self.connection.commit()

        if self.connection.execute("SELECT COUNT(*) FROM books").fetchone()[0] == 0:
            self.connection.executemany(
                """
                INSERT INTO books (title, author, year, genre, total, available)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                DEMO_BOOKS,
            )
            self.connection.commit()

    def authenticate(self, username, password):
        return self.connection.execute(
            "SELECT * FROM users WHERE username = ? AND password = ?",
            (username.strip(), password),
        ).fetchone()

    def get_books(self):
        return self.connection.execute(
            "SELECT * FROM books ORDER BY id"
        ).fetchall()

    def search_books(self, query):
        pattern = f"%{query.strip().lower()}%"
        return self.connection.execute(
            """
            SELECT * FROM books
            WHERE LOWER(title) LIKE ? OR LOWER(author) LIKE ? OR LOWER(genre) LIKE ?
            ORDER BY id
            """,
            (pattern, pattern, pattern),
        ).fetchall()

    def add_book(self, title, author, year, genre, total):
        self.connection.execute(
            """
            INSERT INTO books (title, author, year, genre, total, available)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (title, author, year, genre, total, total),
        )
        self.connection.commit()

    def update_book(self, book_id, title, author, year, genre, total):
        book = self.connection.execute(
            "SELECT total, available FROM books WHERE id = ?", (book_id,)
        ).fetchone()
        issued = book["total"] - book["available"]
        if total < issued:
            raise ValueError(
                f"Новое общее количество не может быть меньше числа выданных экземпляров ({issued})."
            )
        available = total - issued
        self.connection.execute(
            """
            UPDATE books
            SET title = ?, author = ?, year = ?, genre = ?, total = ?, available = ?
            WHERE id = ?
            """,
            (title, author, year, genre, total, available, book_id),
        )
        self.connection.commit()

    def delete_book(self, book_id):
        active_loans = self.connection.execute(
            "SELECT COUNT(*) FROM loans WHERE book_id = ? AND returned = 0",
            (book_id,),
        ).fetchone()[0]
        if active_loans:
            raise ValueError("Нельзя удалить книгу, пока у читателей есть выданные экземпляры.")
        self.connection.execute("DELETE FROM loans WHERE book_id = ?", (book_id,))
        self.connection.execute("DELETE FROM books WHERE id = ?", (book_id,))
        self.connection.commit()

    def issue_book(self, book_id, reader_name):
        book = self.connection.execute(
            "SELECT available FROM books WHERE id = ?", (book_id,)
        ).fetchone()
        if not book:
            raise ValueError("Книга не найдена.")
        if book["available"] <= 0:
            raise ValueError("Свободных экземпляров этой книги нет.")
        self.connection.execute(
            "UPDATE books SET available = available - 1 WHERE id = ?", (book_id,)
        )
        self.connection.execute(
            """
            INSERT INTO loans (book_id, reader_name, issue_date, returned)
            VALUES (?, ?, ?, 0)
            """,
            (book_id, reader_name.strip(), date.today().isoformat()),
        )
        self.connection.commit()

    def return_book(self, book_id):
        loan = self.connection.execute(
            """
            SELECT id FROM loans
            WHERE book_id = ? AND returned = 0
            ORDER BY id DESC LIMIT 1
            """,
            (book_id,),
        ).fetchone()
        if not loan:
            raise ValueError("У этой книги нет активных выдач.")
        book = self.connection.execute(
            "SELECT total, available FROM books WHERE id = ?", (book_id,)
        ).fetchone()
        if book["available"] >= book["total"]:
            raise ValueError("Все экземпляры этой книги уже находятся в библиотеке.")
        self.connection.execute(
            "UPDATE loans SET returned = 1 WHERE id = ?", (loan["id"],)
        )
        self.connection.execute(
            "UPDATE books SET available = available + 1 WHERE id = ?", (book_id,)
        )
        self.connection.commit()

    def get_active_loans(self):
        return self.connection.execute(
            """
            SELECT loans.id, loans.book_id, books.title, books.author,
                   loans.reader_name, loans.issue_date
            FROM loans
            JOIN books ON books.id = loans.book_id
            WHERE loans.returned = 0
            ORDER BY loans.issue_date DESC, loans.id DESC
            """
        ).fetchall()


class BaseView(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=12)
        self.pack(fill="both", expand=True)


class LoginWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Библиотечная система — Вход")
        self.geometry("420x260")
        self.resizable(False, False)
        self.db = LibraryDatabase(DB_PATH)
        self.protocol("WM_DELETE_WINDOW", self.close_app)

        frame = ttk.Frame(self, padding=30)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Вход в систему", font=("Segoe UI", 16, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 20)
        )
        ttk.Label(frame, text="Логин:").grid(row=1, column=0, sticky="e", padx=(0, 10), pady=5)
        ttk.Label(frame, text="Пароль:").grid(row=2, column=0, sticky="e", padx=(0, 10), pady=5)

        self.username_entry = ttk.Entry(frame, width=25)
        self.password_entry = ttk.Entry(frame, width=25, show="*")
        self.username_entry.grid(row=1, column=1, pady=5)
        self.password_entry.grid(row=2, column=1, pady=5)

        buttons = ttk.Frame(frame)
        buttons.grid(row=3, column=0, columnspan=2, pady=(20, 0))
        ttk.Button(buttons, text="Войти", command=self.login, width=14).pack(side="left", padx=5)
        ttk.Button(buttons, text="Выход", command=self.close_app, width=14).pack(side="left", padx=5)

        self.username_entry.bind("<Return>", lambda event: self.login())
        self.password_entry.bind("<Return>", lambda event: self.login())
        self.username_entry.focus()

    def login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        user = self.db.authenticate(username, password)
        if not user:
            messagebox.showerror("Ошибка входа", "Неверный логин или пароль.")
            self.password_entry.select_range(0, tk.END)
            return

        self.withdraw()
        main = MainWindow(self, self.db, user)
        main.protocol("WM_DELETE_WINDOW", self.close_app)

    def close_app(self):
        self.db.connection.close()
        self.destroy()


class MainWindow(tk.Toplevel):
    def __init__(self, login_window, db, user):
        super().__init__(login_window)
        self.login_window = login_window
        self.db = db
        self.user = user
        self.title("Библиотечная система")
        self.geometry("1000x620")
        self.minsize(850, 500)
        self.current_view = None

        header = ttk.Frame(self, padding=(12, 10))
        header.pack(fill="x")
        ttk.Label(
            header,
            text="Библиотечная система",
            font=("Segoe UI", 16, "bold"),
        ).pack(side="left")
        role_name = "Администратор" if user["role"] == "admin" else "Библиотекарь"
        ttk.Label(header, text=f"{role_name}: {user['username']}").pack(side="right")

        nav = ttk.Frame(self, padding=(12, 5))
        nav.pack(fill="x")
        if user["role"] == "admin":
            ttk.Button(nav, text="Добавить книгу", command=self.show_add_form).pack(
                side="left", padx=3
            )
        ttk.Button(nav, text="Список книг", command=self.show_catalog).pack(
            side="left", padx=3
        )
        ttk.Button(nav, text="Поиск", command=self.show_search).pack(side="left", padx=3)
        ttk.Button(nav, text="Выдать книгу", command=self.show_issue).pack(
            side="left", padx=3
        )
        ttk.Button(nav, text="Вернуть книгу", command=self.show_return).pack(
            side="left", padx=3
        )
        ttk.Button(nav, text="Выданные книги", command=self.show_loans).pack(
            side="left", padx=3
        )
        ttk.Button(nav, text="Выйти из аккаунта", command=self.logout).pack(
            side="right", padx=3
        )

        self.content = ttk.Frame(self)
        self.content.pack(fill="both", expand=True)
        self.show_catalog()

    def clear_view(self):
        if self.current_view is not None:
            self.current_view.destroy()
        self.current_view = ttk.Frame(self.content)
        self.current_view.pack(fill="both", expand=True)

    def configure_tree(self, tree, columns):
        tree["columns"] = columns
        tree["show"] = "headings"

    def show_catalog(self):
        self.clear_view()
        view = ttk.Frame(self.content, padding=12)
        view.pack(fill="both", expand=True)
        self.current_view = view

        toolbar = ttk.Frame(view)
        toolbar.pack(fill="x", pady=(0, 8))
        ttk.Label(toolbar, text="Каталог книг", font=("Segoe UI", 13, "bold")).pack(side="left")
        if self.user["role"] == "admin":
            ttk.Button(toolbar, text="Редактировать", command=lambda: self.edit_selected(view)).pack(
                side="right", padx=3
            )
            ttk.Button(toolbar, text="Удалить", command=lambda: self.delete_selected(view)).pack(
                side="right", padx=3
            )

        columns = ("id", "title", "author", "year", "genre", "total", "available")
        tree = ttk.Treeview(view, columns=columns, show="headings", selectmode="browse")
        headings = {
            "id": "Номер",
            "title": "Название",
            "author": "Автор",
            "year": "Год",
            "genre": "Жанр",
            "total": "Всего",
            "available": "Доступно",
        }
        widths = {"id": 60, "title": 220, "author": 180, "year": 70, "genre": 120, "total": 70, "available": 85}
        for column in columns:
            tree.heading(column, text=headings[column])
            tree.column(column, width=widths[column], anchor="w", stretch=column in ("title", "author"))

        scrollbar = ttk.Scrollbar(view, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        tree._book_view = True
        self.refresh_catalog(tree)

    def refresh_catalog(self, tree, books=None):
        for item in tree.get_children():
            tree.delete(item)
        if books is None:
            books = self.db.get_books()
        for book in books:
            tree.insert(
                "",
                "end",
                values=(
                    book["id"],
                    book["title"],
                    book["author"],
                    book["year"],
                    book["genre"],
                    book["total"],
                    book["available"],
                ),
            )

    def get_selected_book(self, view):
        tree = None
        for widget in view.winfo_children():
            if isinstance(widget, ttk.Treeview):
                tree = widget
                break
        if tree is None or not tree.selection():
            messagebox.showwarning("Нет выбора", "Выберите книгу в таблице.")
            return None
        book_id = int(tree.item(tree.selection()[0], "values")[0])
        return self.db.connection.execute(
            "SELECT * FROM books WHERE id = ?", (book_id,)
        ).fetchone()

    def show_add_form(self):
        self.clear_view()
        view = ttk.Frame(self.content, padding=20)
        view.pack(fill="both", expand=True)
        self.current_view = view
        ttk.Label(view, text="Добавление книги", font=("Segoe UI", 13, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 15), sticky="w"
        )
        self.build_book_form(view)

    def build_book_form(self, view, book=None):
        labels = ["Название книги", "Автор", "Год издания", "Жанр", "Количество экземпляров"]
        for row, label in enumerate(labels, start=1):
            ttk.Label(view, text=label + ":").grid(row=row, column=0, sticky="e", padx=(0, 10), pady=5)

        title_entry = ttk.Entry(view, width=45)
        author_entry = ttk.Entry(view, width=45)
        year_entry = ttk.Entry(view, width=45)
        genre_entry = ttk.Entry(view, width=45)
        total_entry = ttk.Entry(view, width=45)

        entries = [title_entry, author_entry, year_entry, genre_entry, total_entry]
        for row, entry in enumerate(entries, start=1):
            entry.grid(row=row, column=1, sticky="w", pady=5)

        if book:
            title_entry.insert(0, book["title"])
            author_entry.insert(0, book["author"])
            year_entry.insert(0, str(book["year"]))
            genre_entry.insert(0, book["genre"])
            total_entry.insert(0, str(book["total"]))

        def save():
            title = title_entry.get().strip()
            author = author_entry.get().strip()
            year_text = year_entry.get().strip()
            genre = genre_entry.get().strip()
            total_text = total_entry.get().strip()
            if not title or not author or not genre:
                messagebox.showwarning("Проверка данных", "Название, автор и жанр обязательны.")
                return
            try:
                year = int(year_text)
                total = int(total_text)
            except ValueError:
                messagebox.showerror("Ошибка ввода", "Год и количество экземпляров должны быть целыми числами.")
                return
            if year < 1 or year > date.today().year:
                messagebox.showerror("Ошибка ввода", f"Введите год от 1 до {date.today().year}.")
                return
            if total < 0:
                messagebox.showerror("Ошибка ввода", "Количество экземпляров не может быть отрицательным.")
                return

            try:
                if book:
                    self.db.update_book(book["id"], title, author, year, genre, total)
                    messagebox.showinfo("Готово", "Данные книги изменены.")
                else:
                    self.db.add_book(title, author, year, genre, total)
                    messagebox.showinfo("Готово", "Книга добавлена.")
                self.show_catalog()
            except ValueError as error:
                messagebox.showerror("Ошибка", str(error))

        action = "Сохранить изменения" if book else "Сохранить книгу"
        buttons = ttk.Frame(view)
        buttons.grid(row=6, column=0, columnspan=2, pady=(15, 0), sticky="w")
        ttk.Button(buttons, text=action, command=save).pack(side="left", padx=(0, 5))
        ttk.Button(buttons, text="Отмена", command=self.show_catalog).pack(side="left")

    def edit_selected(self, view):
        book = self.get_selected_book(view)
        if book is None:
            return
        self.clear_view()
        edit_view = ttk.Frame(self.content, padding=20)
        edit_view.pack(fill="both", expand=True)
        self.current_view = edit_view
        ttk.Label(edit_view, text="Редактирование книги", font=("Segoe UI", 13, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 15), sticky="w"
        )
        self.build_book_form(edit_view, book)

    def delete_selected(self, view):
        book = self.get_selected_book(view)
        if book is None:
            return
        if not messagebox.askyesno(
            "Удаление книги",
            f'Удалить книгу "{book["title"]}"?',
        ):
            return
        try:
            self.db.delete_book(book["id"])
            messagebox.showinfo("Готово", "Книга удалена.")
            self.show_catalog()
        except ValueError as error:
            messagebox.showerror("Ошибка удаления", str(error))

    def show_search(self):
        self.clear_view()
        view = ttk.Frame(self.content, padding=12)
        view.pack(fill="both", expand=True)
        self.current_view = view

        search_bar = ttk.Frame(view)
        search_bar.pack(fill="x", pady=(0, 8))
        ttk.Label(search_bar, text="Поиск по названию, автору или жанру:").pack(
            side="left", padx=(0, 8)
        )
        query_entry = ttk.Entry(search_bar, width=35)
        query_entry.pack(side="left")

        columns = ("id", "title", "author", "year", "genre", "total", "available")
        tree = ttk.Treeview(view, columns=columns, show="headings")
        headings = ("Номер", "Название", "Автор", "Год", "Жанр", "Всего", "Доступно")
        for column, heading in zip(columns, headings):
            tree.heading(column, text=heading)
            tree.column(column, width=120, stretch=True)
        tree.column("id", width=60, stretch=False)
        tree.column("year", width=70, stretch=False)
        scrollbar = ttk.Scrollbar(view, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def run_search():
            query = query_entry.get()
            if not query.strip():
                messagebox.showwarning("Поиск", "Введите текст для поиска.")
                return
            books = self.db.search_books(query)
            self.refresh_catalog(tree, books)
            if not books:
                messagebox.showinfo("Поиск", "Совпадений не найдено.")

        ttk.Button(search_bar, text="Найти", command=run_search).pack(side="left", padx=8)
        query_entry.bind("<Return>", lambda event: run_search())
        query_entry.focus()

    def show_issue(self):
        self.clear_view()
        view = ttk.Frame(self.content, padding=12)
        view.pack(fill="both", expand=True)
        self.current_view = view
        ttk.Label(view, text="Выдача книги", font=("Segoe UI", 13, "bold")).pack(anchor="w")

        form = ttk.Frame(view)
        form.pack(fill="x", pady=10)
        ttk.Label(form, text="Книга:").grid(row=0, column=0, sticky="e", padx=(0, 8), pady=5)
        ttk.Label(form, text="Имя читателя:").grid(row=1, column=0, sticky="e", padx=(0, 8), pady=5)

        book_values = [
            f"{book['id']} — {book['title']} (доступно: {book['available']})"
            for book in self.db.get_books()
        ]
        book_combo = ttk.Combobox(form, values=book_values, width=55, state="readonly")
        reader_entry = ttk.Entry(form, width=55)
        book_combo.grid(row=0, column=1, pady=5)
        reader_entry.grid(row=1, column=1, pady=5)

        def issue():
            if not book_combo.current() >= 0:
                messagebox.showwarning("Проверка", "Выберите книгу.")
                return
            reader_name = reader_entry.get().strip()
            if not reader_name:
                messagebox.showwarning("Проверка", "Введите имя читателя.")
                return
            book_id = int(book_combo.get().split(" — ", 1)[0])
            try:
                self.db.issue_book(book_id, reader_name)
                messagebox.showinfo("Готово", "Книга выдана.")
                self.show_issue()
            except ValueError as error:
                messagebox.showerror("Ошибка выдачи", str(error))

        ttk.Button(form, text="Выдать", command=issue).grid(
            row=2, column=1, pady=(10, 0), sticky="w"
        )

    def show_return(self):
        self.clear_view()
        view = ttk.Frame(self.content, padding=12)
        view.pack(fill="both", expand=True)
        self.current_view = view
        ttk.Label(view, text="Возврат книги", font=("Segoe UI", 13, "bold")).pack(anchor="w")

        form = ttk.Frame(view)
        form.pack(fill="x", pady=10)
        ttk.Label(form, text="Выданная книга:").grid(row=0, column=0, sticky="e", padx=(0, 8))

        active_loans = self.db.get_active_loans()
        loan_values = [
            f"{loan['book_id']} — {loan['title']} | читатель: {loan['reader_name']}"
            for loan in active_loans
        ]
        loan_combo = ttk.Combobox(form, values=loan_values, width=65, state="readonly")
        loan_combo.grid(row=0, column=1)

        def return_book():
            if not loan_combo.get():
                messagebox.showwarning("Проверка", "Выберите выданную книгу.")
                return
            book_id = int(loan_combo.get().split(" — ", 1)[0])
            try:
                self.db.return_book(book_id)
                messagebox.showinfo("Готово", "Книга возвращена.")
                self.show_return()
            except ValueError as error:
                messagebox.showerror("Ошибка возврата", str(error))

        ttk.Button(form, text="Вернуть", command=return_book).grid(
            row=1, column=1, pady=(10, 0), sticky="w"
        )
        if not active_loans:
            ttk.Label(view, text="Активных выдач нет.", foreground="gray").pack(anchor="w", pady=10)

    def show_loans(self):
        self.clear_view()
        view = ttk.Frame(self.content, padding=12)
        view.pack(fill="both", expand=True)
        self.current_view = view
        ttk.Label(view, text="Список выданных книг", font=("Segoe UI", 13, "bold")).pack(
            anchor="w", pady=(0, 8)
        )

        columns = ("loan_id", "book_id", "title", "author", "reader", "date")
        tree = ttk.Treeview(view, columns=columns, show="headings")
        headings = ("№ выдачи", "№ книги", "Название", "Автор", "Читатель", "Дата выдачи")
        widths = (75, 75, 220, 170, 180, 110)
        for column, heading, width in zip(columns, headings, widths):
            tree.heading(column, text=heading)
            tree.column(column, width=width, anchor="w", stretch=column in ("title", "author", "reader"))

        scrollbar = ttk.Scrollbar(view, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        loans = self.db.get_active_loans()
        for loan in loans:
            tree.insert(
                "",
                "end",
                values=(
                    loan["id"],
                    loan["book_id"],
                    loan["title"],
                    loan["author"],
                    loan["reader_name"],
                    loan["issue_date"],
                ),
            )
        if not loans:
            ttk.Label(view, text="Активных выдач нет.", foreground="gray").place(
                relx=0.5, rely=0.5, anchor="center"
            )

    def logout(self):
        if messagebox.askyesno("Выход", "Выйти из аккаунта?"):
            self.destroy()
            self.login_window.username_entry.delete(0, tk.END)
            self.login_window.password_entry.delete(0, tk.END)
            self.login_window.deiconify()
            self.login_window.username_entry.focus()


def main():
    app = LoginWindow()
    app.mainloop()


if __name__ == "__main__":
    main()
